
from threading import Thread

NOT_STARTED = 0
RUNNING = 1
PAUSED = 2
STOP = 3


class MonitoredThread(Thread):
    def __init__(self, monitor, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.monitor = monitor
        self.monitor.add_thread(self)

    def start(self):
        self.monitor.start()
        Thread.start(self)

    def run(self):
        while self.monitor.is_running():
            while self.monitor.is_paused():
                pass

            self.loop()

    def stop(self):
        self.connections.close()


class Monitor:
    def __init__(self):
        self.status = NOT_STARTED
        self.threads = list()

    def add_thread(self, t):
        self.threads.append(t)

    def is_running(self):
        return (self.status == RUNNING or self.status == PAUSED)

    def is_paused(self):
        return self.status == PAUSED

    def start(self):
        self.status = RUNNING

    def stop(self):
        self.status = STOP

        for t in self.threads:
            t.stop()

    def pause(self):
        self.status = PAUSED
