
from abc import ABCMeta, abstractmethod


class AttackOption:
    NO_ARGUMENT = 0
    OPTIONAL_ARGUMENT = 1
    REQUIRED_ARGUMENT = 2

    def __init__(self, name, has_arg, default=None, parser=None):
        self.name = name
        self.has_arg = has_arg

        if has_arg == self.NO_ARGUMENT and default is None:
            self.default = False
        else:
            self.default = default

        if parser is not None:
            self.parser = parser
        else:
            self.parser = lambda x: x

    def parse(self, arg):
        return self.parser(arg)


class Attack:
    options = []
    __meta__ = ABCMeta

    @classmethod
    def parse_options_to_getopt(cls):
        cls.__opts__ = {}

        for option in cls.options:
            cls.__opts__['--' + option.name] = option
            yield option.encode_as_getopt()

    @abstractmethod
    def attack(self):
        pass
