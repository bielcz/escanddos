'''
Util classes
'''


class ConnectionList(list):
    def replace(self, connection, new_one):
        idx = self.index(connection)
        self[idx] = new_one

    def close(self):
        for sck in self:
            sck.close()
