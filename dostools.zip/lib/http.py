'''
HTTP related services.
'''

import socket
import ssl
from urlparse import urlsplit


class HTTPConnection:
    '''
    HTTP connection interface
    '''
    def __init__(self, secure=False):
        '''

        secure: Use SSL (HTTPS)
        '''
        self.con = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        if secure:
            self.con = ssl.wrap_socket(self.con)

    def connect(self, host):
        '''
        Connect to a remote host

        host: a tuple of (host, port), just like socket.connect
        '''
        self.con.connect(host)

    def send_method(self, method, path):
        '''
        Starts the HTTP request by sending the method and path

        e.g.: GET / HTTP/1.1

        method: HTTP method (GET, POST, HEAD, etc)
        path: resource path
        '''
        self.send('{method} /{path} HTTP/1.1\n'.format(
            method=method,
            path=path
        ))

    def send_header(self, header, value):
        '''
        Send a HTTP header

        e.g.: Host: www.example.com

        header: header name
        value: header value
        '''
        self.send('{header}: {value}\n'.format(header=header, value=value))

    def send(self, data):
        '''
        Send data (string) through socket connection
        '''
        self.con.send(data)

    def finish(self):
        '''
        Send a line-feed, if any header has been sent it completes
        the double line-feed to end the request
        (does not finish the connection).
        '''
        self.send('\n')

    def close(self):
        '''
        Close the socket connection
        '''
        self.con.close()


class HTTPClient:
    '''
    A very simple HTTP client that does not handle HTTP responses.

    * Parses a URL and make a HTTP request
    * Support to add default headers
    * Works with HTTPS
    * Does not send a ending line-feed
    '''
    def __init__(self):
        self.default_headers = list()

    def request(self, method, url, headers={}):
        '''
        Make a complete HTTP request and returns the used connection.

        method: HTTP method (GET, POST, HEAD, etc)
        url: the complete URL to request (eg: http://www.example.com/)
        headers: a dict with HTTP headers

        return: a HTTPConnection instance
        '''
        target = urlsplit(url)
        con = HTTPConnection(target.scheme == 'https')

        if target.netloc.find(':') >= 0:
            host, port = target.netloc.split(':')
        else:
            host = target.netloc
            port = 80 if target.scheme == 'http' else 443

        con.connect((host, int(port)))

        con.send_method(method.upper(), target.path)
        con.send_header('Host', target.netloc)

        for header, value in self.default_headers:
            con.send_header(header, value)

        for header, value in headers.items():
            con.send_header(header, value)

        return con

    def get(self, url, headers={}):
        '''
        Make a HTTP GET request.

        return: a HTTPConnection instance
        '''
        return self.request('get', url, headers)

    def post(self, url, headers={}, data=''):
        '''
        Make HTTP POST request and send data param.

        data: a buffer to be sent in POST request

        return: a HTTPConnection instance
        '''
        con = self.request('post', url, headers)
        con.send(data)

        return con

    def add_default_header(self, header, value):
        '''
        Add a header to be sent in every single request.
        '''
        self.default_headers.append((header, value))

    def add_default_headers(self, headers):
        '''
        A multiple headers as default.

        headers: a list of tuples (header, value) or a dict with headers.
        '''
        if isinstance(headers, dict):
            _headers = headers.items()
        elif isinstance(headers, list):
            _headers = headers

        for header, value in _headers:
            self.add_default_header(header, value)


class ActiveHTTPClient(HTTPClient):
    '''
    A HTTP client that send requests and ignore responses.

    It finishes the HTTP request by sending a line-feed.
    '''
    def __init__(self):
        HTTPClient.__init__(self)

    def request(self, method, url, headers={}):
        con = HTTPClient.request(self, method, url, headers)
        con.finish()

        return con
