
import sys
import getopt
from .attack import AttackOption


def encode_option(option):
    return option.name + (
        '=' if option.has_arg == option.REQUIRED_ARGUMENT else ''
    )


def encode_all(attack_class, options):
    for option in attack_class.options:
        options['--' + option.name] = option
        yield encode_option(option)


def iter_options(opts, options):
    for opt, arg in opts:
        yield options[opt], arg


def main(attack_class):
    options = dict()
    opts, args = getopt.getopt(
        sys.argv[1:], '', list(encode_all(attack_class, options))
    )
    kwargs = {}

    for option, arg in iter_options(opts, options):
        if option.has_arg == AttackOption.NO_ARGUMENT:
            arg = bool(arg)

        if option.name in kwargs:
            if isinstance(kwargs[option.name], list):
                kwargs[option.name].append(option.parse(arg))
            else:
                kwargs[option.name] = [
                    kwargs[option.name],
                    option.parse(arg)
                ]
        else:
            kwargs[option.name] = option.parse(arg)

    for opt in attack_class.options:
        if opt.name not in kwargs:
            if opt.default is not None:
                kwargs[opt.name] = opt.default

    attack = attack_class(*args, **kwargs)
    attack.attack()
